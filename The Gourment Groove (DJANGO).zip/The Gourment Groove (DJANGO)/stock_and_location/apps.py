from django.apps import AppConfig


class StockAndLocationConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'stock_and_location'
